print("Enter a positive number to continue, negative to quit")
cont = True
while cont == True:
	num = int(input("> "))
	if num % 2 == 0:
		print(f"{num} is even.")
	else:
		print(f"{num} is odd.")
	if num < 0:
		cont = False