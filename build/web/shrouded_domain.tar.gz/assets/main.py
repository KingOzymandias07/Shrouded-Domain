# NOTE for next time:

import random
import os
import sys
import pygame

pygame.mixer.init()

from pathlib import Path
from vars.classes import *
from map.johnson_hall import *
from map.tutorial import *
from vars.audio import *
from vars.actors import *

BASE_DIR = Path(__file__).parent
ASSET_DIR = BASE_DIR / "assets"
TEXT_DIR = ASSET_DIR / "text"

directions = ["north", "north east", "east", "south east", "south", "south west", "west", "north west", "up", "down"]
def get_text(txt_file):                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
    return (TEXT_DIR / txt_file).read_text(encoding="utf-8").strip()

class TextAdventure:
    def __init__(self):
        self.current_room = john_room8 #change in the future
        self.previous_room = self.current_room
        self.health = 5
        self.max_health = 5
        self.monster_kills = 0
        self.npc_kills = 0
        self.current_weapon = fists
        self.treasures_list = []
        self.treasures = len(self.treasures_list)
        self.inventory = [first_aid_kit]

    def look(self):
        print(f"    {get_room_desc(self.current_room.description)}")
        for npc in self.current_room.npc_list:
            print(f"{get_npc_desc(npc.description)}")
        print()
        print(f"Available Paths: {self.current_room.list_connections()}")
        print()
        for way in directions:
            if self.current_room.get_connections(way):
                if self.current_room.get_connections(way).locked == True:
                    print(f"There is a locked door to the {way}.")
        for actor in self.current_room.interactable:
            print(f"There is {actor.name} here.")
        for item in self.current_room.item_list:
            if type(item) == Actor.Object.Item:
                print(f"There is {get_item_desc(item.description)} here.")
            if type(item) == Actor.Object.Weapon.Melee or type(item) == Actor.Object.Weapon.Ranged:
                print(f"There is {get_weapon_desc(item.description)} here.")
        for monster in self.current_room.monster_list:
            print(f"There is {get_monster_desc(monster.description)} here.")
        return

    def go(self, direction):
        next_room = self.current_room.get_connections(direction)
        if next_room:
            if next_room.locked == False:
                if self.current_room.monster_list != []:
                    self.monster_atk()
                    print()
                move_sound(self, direction)
                self.current_room = next_room
                print(self.current_room.name)
                if self.current_room.visited == False:
                    self.look()
            else:
                print("You can't go that way.")
                sounds["locked"].play()
        else:
            print("You can't go that way.")
        
    def examine(self, name):
        if name == "self" or name == "myself":
            print(f"Detective {username}\n     HP:             {self.health}/{self.max_health}")
            print(f"Current Weapon: {self.current_weapon.name}\n     Weapon Damage:  {self.current_weapon.min_damage}-{self.current_weapon.max_damage}")
            if self.monster_kills > 0:
                print(f"Enemies Defeated:    {self.monster_kills}")
            if self.npc_kills > 0:
                print(f"NPCs Killed:         {self.npc_kills}")
            if self.treasures > 0:
                print(f"Treasures:           {self.treasures}/(TBD)")
            return
        else:
            for item in self.inventory:
                if item.name.lower() == name:
                    if type(item) == Actor.Object.Item:
                        print(f"Item:   {item.name}")
                        print(f"{get_item_desc(item.description)}")
                    if type(item) == Actor.Object.Heal:
                        print(f"Item:   {item.name}")
                        print(f"Health: {item.hp}")
                        print(f"{get_item_desc(item.description)}")
                    if type(item) == Actor.Object.Interactable:
                        print(f"Item:   {item.name}")
                        actor = item
                        if actor.name.lower() == name.lower():
                            print(get_desc(actor.description))
                            for item in actor.item_list:
                                self.inventory.append(item)
                                actor.item_list.remove(item) 
                            actor.description = actor.description.replace(".txt", "0.txt")
                    return


            for monster in self.current_room.monster_list:
                if monster.name.lower() == name:
                    print(f"Monster: {monster.name}")
                    print(f"    HP:      {monster.hp}/{monster.max_hp}")
                    return
            print(f"You do not have {name}.")

            for actor in self.current_room.interactable:
                if actor.name.lower() == name.lower():
                    print(get_desc(actor.description))
                    for item in actor.item_list:
                        self.current_room.item_list.append(item)
                        actor.item_list.remove(item)   
                    actor.description = actor.description.replace(".txt", "0.txt")

    def talk(self, name):
        for npc in self.current_room.npc_list:
            if npc.name == name.lower():
                dialogue_file = open(DIALOGUE_DIR / npc.dialogue)
 
    def take(self, name):
        for objects in self.current_room.item_list:
            if objects.name.lower() == name:
                self.inventory.append(objects)
                self.current_room.item_list.remove(objects)
                print(f"You picked up the {objects.name}.")
                return
        for actor in self.current_room.interactable:
            if actor.takable == True:
                self.inventory.append(actor)
                self.current_room.interactable.remove(actor)
                print(f"You picked up the {actor.name}")
                return
        print(f"There is no {name} here.")

    def use(self, name):
        for item in self.inventory:
            if item.name.lower() == name:
                if type(item) == Actor.Object.Item:
                    self.use_item(item)
                    return
                if type(item) == Actor.Object.Heal:
                    self.use_heal()
                    return
                if type(item) == Actor.Object.Weapon.Melee:
                    self.equip(item)
                if type(item) == Actor.Object.Weapon.Ranged:
                    self.equip(item)
        for actor in self.current_room.interactable:
            if actor.name.lower() == name:
                self.interact(actor)
                return

    def interact(self, actor):
        if actor.function == "lever":
            print("Pull lever?")
            ans = input("> ").lower()
            if ans == "yes" or ans == "y":
                sounds["lever"].play                
                actor.room_use.get_connections(actor.directional_use).locked == False
                if actor.room_use == self.current_room:
                    print("A way has opened.")
                    sounds["moving stone"].play
                if actor.room_use != self.current_room:
                    print("You flipped the switch.")

    def use_heal(self, item):
        self.health += item.health
        if self.health > self.max_health:
            healed = self.health - self.max_health
            self.health = self.max_health
            print(f"You healed {healed} HP.")
        else:
            print(f"You healed {item.health}.")
    def use_item(self, item):
        if item.function == "key":
            self.use_key(item)
            return

    def equip(self, item):
        if item in self.inventory:
            if self.current_weapon != fists:
                self.inventory.append(self.current_weapon)
            self.current_weapon = item
            print(f"You equipped the {item.name}.")
            self.inventory.remove(item)
        else:
            print(f"You don't have {item}.")

    def unequip(self):
        if self.current_weapon != fists:
            item = self.current_weapon
            self.inventory.append(item)
            self.current_weapon = fists
            print(f"You unequipped the {item.name}")
        else:
            print("You can't unequip your fists.")

    def use_key(self, item):
        if item.room_use == self.current_room:
            self.current_room.get_connections(item.direction_use).locked = False
            sounds["unlock"].play()
            print("You turned the key, and the door unlocked.")
            item.uses -= 1
            if item.uses <= 0:
                print("This key is no longer useful. You threw away the key.")
                self.inventory.remove(item)
            return
        if item.room_use == "any":
            for way in directions:
                if self.current_room.get_connections(way):
                    if self.current_room.get_connections(way).locked == True:
                        self.current_room.get_connections(way).locked = False
                        sounds["unlock"].play
                        item.uses -= 1
            print("You unlocked every door in the area.")
        else:                
            print("You can't use that here.")
        return

    def attack(self, target):
        hit = random.randint(1, self.current_weapon.accuracy)
        dmg = random.randint(self.current_weapon.min_damage, self.current_weapon.max_damage)
        if type(self.current_weapon) == Actor.Object.Weapon.Melee:
            self.melee_atk(target, hit, dmg)
        if type(self.current_weapon) == Actor.Object.Weapon.Ranged:
            self.ranged_atk(target, hit, dmg)  
        self.monster_atk()
            
    def melee_atk(self, target, hit, dmg):
        if hit != 0:
            if target == "self" or target == "myself":
                print("You hit yourself.")
                sounds[self.current_weapon.sound].play()
                print(f"You lost {dmg} HP.")
                self.health -= dmg
                return
            for monster in self.current_room.monster_list:
                if monster.name.lower() == target:
                    print(f"You swung at the {monster.name}.")
                    sounds[self.current_weapon.sound].play()
                    monster.hp -= dmg
                    if monster.hp <= 0:
                        print(f"You killed the {monster.name}!")
                        sounds["kill"].play()
                        monster.hp = monster.max_hp
                        self.current_room.monster_list.remove(monster)
                        self.monster_kills += 1
                    return
            for npc in self.current_room.npc_list:
                if npc.name.lower() == target:
                    print(f"You swung at {npc.name}.")
                    sounds[self.current_weapon.sound].play()
                    npc.health -= dmg
                    if npc.health <= 0:
                        print(f"You killed {npc.name}.")
                        sounds["kill"].play()
                        self.npc_kills += 1
                    return
            print(f"There is no {target} here.")
        else:
            print("You missed.")
            sounds["swoosh"].play()
            return
            
    def ranged_atk(self, target, hit, dmg):
        if hit != 0:
            if self.ammo > 0:
                if target == "self" or target == "myself":
                    print("You shot yourself.")
                    sounds[self.current_weapon.sound].play()
                    print(f"You lost {dmg} HP.")
                    self.health -= dmg
                    self.current_weapon.ammo -= 1
                    return
                for monster in self.current_room.monster_list:
                    if monster.name.lower() == target:
                        print(f"You shot the {monster.name}.")
                        sounds[self.current_weapon.sound].play()
                        monster.health -= dmg
                        self.current_weapon.ammo -= 1
                        if monster.health <= 0:
                            print(f"You killed the {monster.name}!")
                            sounds["kill"].play()
                            monster.health = monster.max_health
                            self.current_room.monster_list.remove(monster)
                            self.monster_kills += 1
                            return
                        return
                for npc in self.current_room.npc_list:
                    if npc.name.lower() == target:
                        print(f"You shot {npc.name}.")
                        sounds[self.current_weapon.sound].play()
                        npc.health -= dmg
                        self.current_weapon.ammo -= 1
                        if npc.health <= 0:
                            print(f"You killed {npc.name}.")
                            sounds["kill"].play()
                            self.npc_kills += 1
                        return
                print(f"There is no {target} here.")
        else:
            print("You missed.")
            self.current_weapon.ammo -= 1
            return
            
    def monster_atk(self):
        print()
        for monster in self.current_room.monster_list:
            hit = random.randint(1, monster.accuracy)
            dmg = random.randint(monster.min_damage, monster.max_damage)
            print(f"The {monster.name} attacked!")
            if hit != 0:
                print(f"You lost {dmg} HP.")
                self.health -= dmg
                sounds[monster.sound].play()
            else:
                print("It missed!")
                sounds["swoosh"].play()
            return

    def drop(self, name):
        if name == "fists":
            print("You can't drop your own hands.")
            return
        for objects in self.inventory:
            if objects.name.lower() == name and type(objects) != Actor.Object.Interactable:
                self.inventory.remove(objects)
                self.current_room.item_list.append(objects)
                print(f"You dropped the {name}.")
                return
        for actor in self.inventory:
            if actor.name.lower() == name and type(actor) == Actor.Object.Interactable:
                self.inventory.remove(actor)
                self.current_room.interactable.append(actor)
                print(f"You dropped the {name}.")
                return
        print(f"You don't have {name}")

    def death(self):
        print(get_text("game over.txt"))
        sounds["death"].play()
        print("Play again?")
        cont = input("> ").lower()
        return cont

def move_sound(self, direction):
    next_room = self.current_room.get_connections(direction)
    if next_room:
        if next_room.locked == True:
            sounds["locked"].play()
            print("The door is locked.")
        else:
            if self.current_room.part == "ext":
                if next_room.part != "ext":
                    sounds["door"].play()
                    return
            elif self.current_room.part != "ext":
                if next_room.part == "ext":
                    sounds["door"].play()
                    return
            elif self.current_room.part == "1st":
                if next_room.part != "1st":
                    print("test 1")
                    if next_room.part != "ext":
                        print("test 2")
                        sounds["stairs"].play()
                        return
            elif self.current_room.part == "2nd":
                if next_room.part != "2nd":
                    if next_room.part != "ext":
                        sounds["stairs"].play()
                        return
            elif self.current_room.part == "3rd":
                if next_room.part != "3rd":
                    if next_room.part != "ext":
                        sounds["stairs"].play()
                        return
            sounds["walk"].play()


### THE GAME ###

running = TextAdventure()
command_list = []

#intro
print(get_text("title screen.txt"))
print("Press enter to begin. (If you are stuck enter 'help')")
print("For a tutorial enter 'tutorial'")
input()
print()
print("Enter your name: ")
username = input("> ").lower

def main():
    play = "yes"
    running.current_room.visited = True
    print(running.current_room.name)
    running.look()

    while play == "yes":

        if running.health <= 0:
            play = running.death()
            if play != "yes":
                break
            os.system('cls')
            print("")
            os.execl(sys.executable, sys.executable, *sys.argv)        
                    
        command = input("> ").lower()

        if command == "quit":
            play = "no"

        elif command.startswith("go"):
            direction = command[3:]
            running.go(direction)

        elif command == "look":
            running.look()

        elif command == "inventory":
            for thing in running.inventory:
                print(thing.name)

        elif command.startswith("take"):
            name = command[5:]
            running.take(name)

        elif command.startswith("use"):
            name = command[4:]
            running.use(name)

        elif command == "help":
            print("")
            print("Helpful commands:")
            print(", ".join(command_list))
            print("")
            print(running.current_room.name)

        elif command.startswith("examine"):
            name = command[8:]
            if name == "":
                print("What are you examining?")
                name = input("> ").lower()
            running.examine(name)

        elif command.startswith("attack") or command.startswith("kill"):
            if command.startswith("attack"):
                target = command[7:]
            if command.startswith("kill"):
                target= command[5:]
            if target == "":
                print("What are you attacking?")
                target = input("> ").lower
            running.attack(target)

        elif command.startswith("drop"):
            name = command[5:]
            if name == "":
                print("What are you dropping?")
                name = input("> ").lower
            running.drop(name)

        elif command.startswith("equip"):
            name = command[6:]
            if name == "":
                print("What are you equipping?")
                name = input("> ").lower
            for item in running.inventory:
                if item.name.lower() == name.lower():
                    running.equip(item)

        elif command.startswith("unequip"):
            running.unequip()

        elif command.startswith("talk"):
            name = command[5:]
            running.talk(name)

        elif command.startswith("tutorial"):
            back_room = running.current_room
            running.current_room = tut_1
            running.current_room.visited = True
            print(running.current_room.name)
            running.look()

        elif command.startswith("exit"):
            if command[5:] == "tutorial":
                running.current_room = back_room
            if back_room.part == "TUT":
                running.current_room = john_front

        else:
            print(f"I don't know '{command}'.")

main()